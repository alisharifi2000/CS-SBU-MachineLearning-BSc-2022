import pandas as pd
from imblearn.over_sampling import RandomOverSampler, SMOTE
from imblearn.under_sampling import RandomUnderSampler

def smote( data ):

    k = 1
    krnl = 150
    Class = data['class']
    NonClass = data.loc[:, data.columns != 'class']
    Smote = SMOTE(sampling_strategy='auto', k_neighbors=k, random_state = krnl)
    NClassRsmpl, ClassRsmpl = Smote.fit_resample( NonClass , Class)
    result = pd.concat([pd.DataFrame(NClassRsmpl), pd.DataFrame(ClassRsmpl)], axis=1)

    return result

def over_smpl(data):

    Class = data.loc[:, data.columns != 'class']
    NonClass = data['class']

    over_smpl = RandomOverSampler(sampling_strategy='minority')
    ClassRsmpl, NonClaassRsmpl = over_smpl.fit_resample(Class, NonClass)

    result = pd.concat([pd.DataFrame(ClassRsmpl), pd.DataFrame(NonClassRsmpl)], axis=1)
    return result

def under_smpl(data):

    Class = data.loc[:, data.columns != 'class']
    NonClass = data['class']

    under_smpl = RandomUnderSampler(sampling_strategy='majority')
    ClassRsmpl, NonClassRsmpl = us.fit_resample(Class, NonClass)

    result = pd.concat([pd.DataFrame(ClassRsmpl), pd.DataFrame(NonClassRsmpl)], axis=1)
    return result




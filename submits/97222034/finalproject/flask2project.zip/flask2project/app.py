from flask import Flask, request
from datetime import date, datetime
from khayyam import *
import re
import json
import pandas as pd
from utils.common import response_message, read_json_time_series
from utils.interpolation_methods import linear_interpolation, outlier, manage_imbalanced_data

app = Flask(__name__)

@app.route('/', methods=['GET', 'POST'])
def isup():
    return response_message('API is active')


@app.route('/service1', methods=['GET', 'POST'])
def interpolation():
    req = request.get_json()
    data = read_json_time_series(req["data"], req["config"]) #convert to dataframe
    config = req["config"]


    if config["type"]=="shamsi":
        result = linear_interpolation(data, config)#timestamp
        for i in range(0, result["time"].size):
            result["time"][i] = (result["time"][i]).strftime("%m-%d-%Y %H-%M-%S")
            str1 = result["time"][i][0:10]
            month, day, year= re.split(r'\s|-', str1)
            result["time"][i] = JalaliDatetime(datetime(int(year), int(month), int(day), 0, 0, 0))
            result["time"][i] = (result["time"][i]).strftime("%Y-%m-%d %H-%M-%S")
    else:
        result = linear_interpolation(data, config)

    result = result.to_json()
    return response_message(dict({"data": result}))



@app.route('/service2', methods=['GET', 'POST'])
def convertandinterpolation():
    req = request.get_json()
    req["config"]["type"] = "miladi"
    data = read_json_time_series(req["data"], req["config"]) #convert to dataframe
    config = req['config']
    result = linear_interpolation(data, config)
    for i in range(0, result["time"].size):
        result["time"][i] = (result["time"][i]).strftime("%m-%d-%Y %H-%M-%S")
        str1 = result["time"][i][0:10]
        month, day, year = re.split(r'\s|-', str1)
        result["time"][i] = JalaliDatetime(datetime(int(year), int(month), int(day), 0, 0, 0))
        result["time"][i] = (result["time"][i]).strftime("%Y-%m-%d %H-%M-%S")
    result = result.to_json()
    return response_message(dict({"data": result}))



@app.route('/service3', methods=['GET', 'POST'])
def outlierdetection():
    req = request.get_json()
    config = req['config']
    j_data = json.dumps(req["data"])
    data = pd.read_json(j_data)
    # data.time = pd.to_datetime(data.time, unit='ms')
    result = outlier(data, config)
    result = result.to_json()
    return response_message(dict({"data": result}))


@app.route('/service4', methods=['GET', 'POST'])
def unbalanced_data():
    req = request.get_json()
    j_data = json.dumps(req["data"])
    data = pd.read_json(j_data)
    config = req['config']
    result = manage_imbalanced_data(data, config)
    result = result.to_json()
    return response_message(dict({"data": result}))


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80)

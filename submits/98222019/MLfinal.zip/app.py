from flask import Flask, request
from common import response_message, read_json_time_series
import pandas as pd
from interpolation_methods import interpolate
import khayyam as kh

app = Flask(__name__)
app.config['SWAGGER'] = {
    "specs_route": "/report/"
}
app.config.from_object(config.Config)
swagger = Swagger(app, template_file='report.yml')

@app.route('/', methods=['GET', 'POST'])
def isup():
    return response_message('API is active')


@app.route('/service1', methods=['GET', 'POST'])
def interpolate_1():
    req = request.get_json()
 
    config = req['config']
    if config['type'] == 'miladi':
        data = read_json_time_series(req['data'] , config['type'])
        result = interpolate(data, config)
        result = result.to_json()
    elif config['type'] == 'shamsi' :
        data = read_json_time_series(req['data'] , config['type'] )
        result = interpolate(data, config)
        result = shamsiSaz(result).to_json()

    return response_message(dict({"data": result}))

@app.route('/service2', methods=['GET', 'POST'])
def interpolate_2():
    req = request.get_json()
 
    config = req['config']
    data = read_json_time_series(req['data'] , type="miladi")
    result = interpolate(data, config)
    result = convert_to_shamsi(result).to_json()
    return response_message(dict({"data": result}))


@app.route('/service4', methods=['GET', 'POST'])

def imblncLearning():
    req = request.get_json()
    config = req['config']
    data = read_json(req['data'])

    if(config['method'] == "SMOTE"):
        result = smote(data)
        result = result.to_json()
    elif(config['method'] == "RANDOM_OVERSAMPLING"):
        result = over_smpl(data)
        result = result.to_json()
    elif(config['method'] == "RANDOM_UNDERSAMPLING"):
        result = under_smpl(data)
        result = result.to_json()


    return response_message(dict({"data": result}))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=80)

from datetime import date, datetime
from khayyam import *
import pandas as pd
import numpy as np
import json
from imblearn.over_sampling import SMOTE
from imblearn.over_sampling import RandomOverSampler
from imblearn.under_sampling import NearMiss
from imblearn.under_sampling import RandomUnderSampler
from sklearn.neighbors import LocalOutlierFactor

def linear_interpolation(data, config):
    if config['time'] == 'daily':
        data = data.set_index('time')
        data = data.resample('D') #turn dates into daily dates
        data = data.interpolate(method=config['interpolation'])
        data.reset_index(inplace=True)

    elif config['time'] == 'monthly':
        data = data.set_index('time')
        data = data.resample('M')
        data = data.interpolate(method=config['interpolation'])
        data.reset_index(inplace=True)
    else:
        data = None
    return data


def outlier(df, config):
    if config["time_series"] == False:
        method1 = dict()
        method2 = dict()
        Q1 = df["feature"].quantile(0.25)
        Q2 = df["feature"].quantile(0.5)
        Q3 = df["feature"].quantile(0.75)
        IQR = Q3 - Q1
        lower_range = Q1 - (1.5 * IQR)
        upper_range = Q3 + (1.5 * IQR)
        for x, y in enumerate(df["feature"]):
            if y < lower_range or y > upper_range:
                method1.update([(f"{x}", True)])
            else:
                method1.update([(f"{x}", False)])
        df["method1"]=method1.values()

        #method2
        mean = np.mean(df["feature"])
        std =  np.std(df["feature"])
        for x, y in enumerate(df["feature"]):
            z = (y -mean) /std
            if z>1:
                method2.update([(f"{x}", False)])
            else:
                method2.update([(f"{x}", True)])
        df["method2"] = method2.values()
        df.drop("feature", axis=1, inplace=True)
        return df

    elif config["time_series"] == True:
        method1 = dict()
        method2 = dict()
        Q1 = df["vol"].quantile(0.25)
        Q2 = df["vol"].quantile(0.5)
        Q3 = df["vol"].quantile(0.75)
        IQR = Q3 - Q1
        lower_range = Q1 - (1.5 * IQR)
        upper_range = Q3 + (1.5 * IQR)
        for x, y in enumerate(df["vol"]):
            if y < lower_range or y > upper_range:
                method1.update([(f"{x}", True)])
            else:
                method1.update([(f"{x}", False)])
        df["method1"] = method1.values()

        # method2
        mean = np.mean(df["vol"])
        std = np.std(df["vol"])
        for x, y in enumerate(df["vol"]):
            z = (y - mean) / std
            if z > 1:
                method2.update([(f"{x}", False)])
            else:
                method2.update([(f"{x}", True)])
        df["method2"] = method2.values()
        df.drop("vol", axis=1, inplace=True)

    else:
        df = None
    return df


def manage_imbalanced_data(df, config):
    major_class = config["major_class"]
    minor_class = config["minor_class"]
    if config["method"] == "SMOTE":
        sm = SMOTE(random_state=2, k_neighbors=1 )
        # df["class"]= sm.fit_resample(df["class"])
        X_over, y_over = sm.fit_resample(df["feature1"].values.reshape(-1, 1), df["class"].values.reshape(-1, 1))
        list1 = (X_over.flatten().tolist())
        df2 = {"feature1_res": list1,
               "class_res": y_over}
        df2 = pd.DataFrame.from_dict(df2)
        return df2


    elif config["method"] == "oversampling":
        oversample = RandomOverSampler(sampling_strategy='minority')
        X_over, y_over = oversample.fit_resample(df["feature1"].values.reshape(-1, 1),df["class"].values.reshape(-1, 1))
        list1= (X_over.flatten().tolist())
        df3 = {"feature1_res": list1,
               "class_res": y_over}
        df3 = pd.DataFrame.from_dict(df3)
        return df3

    elif config["method"] == "undersampling":
        undersample = NearMiss(version=1, n_neighbors=1)
        X_under, y_under = undersample.fit_resample(df["feature1"].values.reshape(-1, 1), df["class"].values.reshape(-1, 1))
        list1 = (X_under.flatten().tolist())
        df4 = {"feature1_res": list1,
               "class_res": y_under}
        df4 = pd.DataFrame.from_dict(df4)
        return df4
    elif config["method"] == "RandomUnderSampler":
        rus = RandomUnderSampler(random_state=42)
        X_under, y_under = rus.fit_resample(df["feature1"].values.reshape(-1, 1), df["class"].values.reshape(-1, 1))
        list1 = (X_under.flatten().tolist())
        df5 = {"feature1_res": list1,
               "class_res": y_under}
        df5 = pd.DataFrame.from_dict(df5)
        return df5

    else:
        df = None
    return df



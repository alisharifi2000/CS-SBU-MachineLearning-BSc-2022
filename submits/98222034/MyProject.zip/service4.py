import pandas as pd
from imblearn.over_sampling import Randomoversample_methodr, SMOTE
from imblearn.under_sampling import Randomundersample_methodr

def oversample_method(data):

    dloc = data.loc[:, data.columns != 'class']
    dclass = data['class']
    rosm = Randomoversample_methodr(sampling_strategy='minority')
    dlocR, dclassR = rosm.fit_resample(dloc, dclass)
    result = pd.concat([pd.DataFrame(dlocR), pd.DataFrame(dclassR)], axis=1)
    return result

def smote( data ):
    k = 1
    dloc = data['class']
    dclass = data.loc[:, data.columns != 'class']
    kern = 200 
    smte = SMOTE(sampling_strategy='auto', k_neighbors=k, random_state = kern)
    dclassR, dlocR = smte.fit_resample( dclass , dloc)
    result = pd.concat([pd.DataFrame(dclassR), pd.DataFrame(dlocR)], axis=1)
    return result

def undersample_method(data):

    dloc = data.loc[:, data.columns != 'class']
    dclass = data['class']
    rusm = Randomundersample_methodr(sampling_strategy='majority')
    dlocR, dclassR = rusm.fit_resample(dloc, dclass)
    result = pd.concat([pd.DataFrame(dlocR), pd.DataFrame(dclassR)], axis=1)
    return result




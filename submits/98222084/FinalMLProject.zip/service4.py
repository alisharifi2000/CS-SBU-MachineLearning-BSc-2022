import pandas as pd
from imblearn.over_sampling import RandomOverSampler, SMOTE
from imblearn.under_sampling import RandomUnderSampler


def oversample(data):

    cl = data.loc[:, data.columns != 'class']
    feId = data['class']

    os = RandomOverSampler(sampling_strategy='minority')
    clResample, feIdResample = os.fit_resample(cl, feId)

    result = pd.concat([pd.DataFrame(clResample), pd.DataFrame(feIdResample)], axis=1)
    return result

def undersample(data):

    cl = data.loc[:, data.columns != 'class']
    feId = data['class']

    us = RandomUnderSampler(sampling_strategy='majority')
    clResample, feIdResample = us.fit_resample(cl, feId)

    result = pd.concat([pd.DataFrame(clResample), pd.DataFrame(feIdResample)], axis=1)
    return result

def smote( data ):
    
    
    cl = data['class']
    feId = data.loc[:, data.columns != 'class']

    k = 1
    kernel = 50

    smt = SMOTE(sampling_strategy='auto', k_neighbors=k, random_state = kernel)
    feIdResample, clResample = smt.fit_resample( feId , cl)
    result = pd.concat([pd.DataFrame(feIdResample), pd.DataFrame(clResample)], axis=1)

    return result


import gzip
from flask import make_response, json
import pandas as pd
import numpy as np
import json
from datetime import *
from khayyam import *

def linear_interpolation(data, config):
    if config['time'] == 'daily':
        data = data.set_index('time')
        data = data.resample('D')
        data = data.interpolate(method=config['interpolation'])
        data.reset_index(inplace=True)

    elif config['time'] == 'monthly':
        data = data.set_index('time')
        data = data.resample('M')
        data = data.interpolate(method=config['interpolation'])
        data.reset_index(inplace=True)

    elif (config['time'] == 'hourly'):
        data = data.set_index('time')
        data = data.resample('1H').mean()
        data = data.interpolate(method=config['interpolation'])
        data.reset_index(inplace=True)

    elif (config['time'] == 'minutes'):
        data = data.set_index('time')
        data = data.resample('1T').mean()
        data = data.interpolate(method=config['interpolation'])
        data.reset_index(inplace=True)
       

    elif (config['time'] == 'seconds'):
        data = data.set_index('time')
        data = data.resample('1S').mean()
        data = data.interpolate(method=config['interpolation'])
        data.reset_index(inplace=True)

    else:
        data = None

    return data

def polynomial_interpolation(data, config):

    if config['time'] == 'daily':
        data = data.set_index('time')
        data = data.resample('D').mean()
        data = data.interpolate(method=config['interpolation'], order = 2)
        data.reset_index(inplace=True)
    elif config['time'] == 'monthly':
        data = data.set_index('time')
        data = data.resample('M').mean()
        data = data.interpolate(method=config['interpolation'], order = 2)
        data.reset_index(inplace=True)
    elif (config['time'] == 'hourly'):
        data = data.set_index('time')
        data = data.resample('1H').mean()
        data = data.interpolate(method=config['interpolation'], order = 2)
        data.reset_index(inplace=True)
    elif (config['time'] == 'minutes'):
        data = data.set_index('time')
        data = data.resample('1T').mean()
        data = data.interpolate(method=config['interpolation'], order = 2)
        data.reset_index(inplace=True)
    elif (config['time'] == 'seconds'):
        data = data.set_index('time')
        data = data.resample('1S').mean()
        data = data.interpolate(method=config['interpolation'], order = 2)
        data.reset_index(inplace=True)


    else:
        data = None

    return data

def interpolate(data, config):
    if (config['interpolation'] == 'linear'):
        return linear_interpolation(data, config)
    elif (config['interpolation'] == 'polynomial'):
        return polynomial_interpolation(data, config)